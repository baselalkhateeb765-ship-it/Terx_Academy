TERX Technologies website
- This is a standalone static website.
- Upload index.html to the root of your GitHub repository.
- On Vercel choose Framework Preset: Other.
- Leave Build Command and Output Directory empty (or use the project root).
- Deploy.
WhatsApp contact is set to the Egyptian number +20 15 07597801 (international digits: 201507597801).
